#!/usr/bin/env python

from time import sleep

while True:
    test = None
    sleep(1)

