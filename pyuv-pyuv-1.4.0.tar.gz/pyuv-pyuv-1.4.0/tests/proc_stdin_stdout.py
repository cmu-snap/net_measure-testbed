#!/usr/bin/env python

from __future__ import print_function

import sys

c = sys.stdin.readline()
print(c)
sys.stdout.flush()

